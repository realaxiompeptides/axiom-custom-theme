AXIOM SEO 100 PAGE PACK

UPLOAD:
1. Unzip this file.
2. Upload the entire /seo folder into your GitHub repository root or hosting file manager.
3. The live index should be: https://axiomresearch.shop/seo/index.html
4. Individual pages should be: https://axiomresearch.shop/seo/page-name.html

IMPORTANT:
- Do not upload the ZIP itself if you want pages to go live. Upload the unzipped /seo folder.
- Every page loads:
  /assets/css/style.css
  /seo/assets/seo.css

If your WordPress/theme CSS path is different, update the first stylesheet line in the HTML files.
